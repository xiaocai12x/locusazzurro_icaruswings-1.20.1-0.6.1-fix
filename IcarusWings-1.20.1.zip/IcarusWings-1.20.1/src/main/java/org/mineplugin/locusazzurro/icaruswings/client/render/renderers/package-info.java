@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package org.mineplugin.locusazzurro.icaruswings.client.render.renderers;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;
