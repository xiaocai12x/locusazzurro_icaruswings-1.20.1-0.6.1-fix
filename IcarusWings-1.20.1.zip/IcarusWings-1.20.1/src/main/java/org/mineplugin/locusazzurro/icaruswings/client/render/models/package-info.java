@ParametersAreNonnullByDefault
package org.mineplugin.locusazzurro.icaruswings.client.render.models;

import javax.annotation.ParametersAreNonnullByDefault;