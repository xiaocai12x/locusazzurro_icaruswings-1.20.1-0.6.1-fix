package org.mineplugin.locusazzurro.icaruswings.common.item;

public class BaseTransportCard extends AbstractTransportCard{

    public BaseTransportCard(){
        super(CardType.BASE);
    }

}
