package org.mineplugin.locusazzurro.icaruswings.common.item;

import net.minecraft.world.item.Rarity;
import org.mineplugin.locusazzurro.icaruswings.common.data.WingsType;



public class MagicWings extends AbstractWings{

	public MagicWings(WingsType type) {
		super(type, Rarity.UNCOMMON);
	}
}
