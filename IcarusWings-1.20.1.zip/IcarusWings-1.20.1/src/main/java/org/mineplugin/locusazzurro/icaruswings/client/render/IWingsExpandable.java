package org.mineplugin.locusazzurro.icaruswings.client.render;

public interface IWingsExpandable {
	
	float getExpansionFactor();
}
